using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClipboardPartTwo
{
	/// <summary>
	/// CustomData stores data in the clipboard
	/// it will store an image and a string
	/// </summary>
	/// 
	[Serializable()]
	public class CustomData
	{
		private static DataFormats.Format format;
		static CustomData()
		{
			// Registers a new data format with the windows Clipboard
			format = DataFormats.GetFormat(typeof(CustomData).FullName);
		}
		
		public static DataFormats.Format Format
		{
			get
			{
				return format;
			}
		}

		private string stringData;
		private Image image;

		public CustomData()
		{
			image = null;
			stringData = "";
		}

		public CustomData(string str, Image img)
		{
			if( img != null )
				image = (Image) img.Clone();
			else
				image = null;

			stringData = str;
		}

		public Image Image
		{
			get
			{
				return image;
			}
			set
			{
				image = value;
			}
		}

		public string String
		{
			get
			{
				return stringData;
			}
			set
			{
				stringData = value;
			}
		}


		public override string ToString()
		{
			return String;
		}
	}
}
