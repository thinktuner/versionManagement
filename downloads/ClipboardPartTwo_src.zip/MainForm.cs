using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ClipboardPartTwo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox imageSrc;
		private System.Windows.Forms.TextBox textSrc;
		private System.Windows.Forms.LinkLabel loadImage;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textDest;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox imageDest;
		private System.Windows.Forms.Button copyImage;
		private System.Windows.Forms.Button copyText;
		private System.Windows.Forms.Button copyCustom;
		private System.Windows.Forms.Button pasteCustom;
		private System.Windows.Forms.Button pasteText;
		private System.Windows.Forms.Button pasteImage;
		private System.Windows.Forms.Button copyAll;
		private System.Windows.Forms.Button viewFormats;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.imageSrc = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textSrc = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.loadImage = new System.Windows.Forms.LinkLabel();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textDest = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.imageDest = new System.Windows.Forms.PictureBox();
			this.copyImage = new System.Windows.Forms.Button();
			this.copyText = new System.Windows.Forms.Button();
			this.copyCustom = new System.Windows.Forms.Button();
			this.pasteCustom = new System.Windows.Forms.Button();
			this.pasteText = new System.Windows.Forms.Button();
			this.pasteImage = new System.Windows.Forms.Button();
			this.copyAll = new System.Windows.Forms.Button();
			this.viewFormats = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.loadImage,
																					this.label2,
																					this.textSrc,
																					this.label1,
																					this.imageSrc});
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(224, 272);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Source";
			// 
			// imageSrc
			// 
			this.imageSrc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.imageSrc.Location = new System.Drawing.Point(8, 32);
			this.imageSrc.Name = "imageSrc";
			this.imageSrc.Size = new System.Drawing.Size(208, 184);
			this.imageSrc.TabIndex = 0;
			this.imageSrc.TabStop = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 224);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Text data";
			// 
			// textSrc
			// 
			this.textSrc.Location = new System.Drawing.Point(8, 240);
			this.textSrc.Name = "textSrc";
			this.textSrc.Size = new System.Drawing.Size(208, 20);
			this.textSrc.TabIndex = 1;
			this.textSrc.Text = "";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "Image data";
			// 
			// loadImage
			// 
			this.loadImage.AutoSize = true;
			this.loadImage.Location = new System.Drawing.Point(144, 16);
			this.loadImage.Name = "loadImage";
			this.loadImage.Size = new System.Drawing.Size(73, 13);
			this.loadImage.TabIndex = 0;
			this.loadImage.TabStop = true;
			this.loadImage.Text = "Load image...";
			this.loadImage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.loadImage_LinkClicked);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.label3,
																					this.textDest,
																					this.label4,
																					this.imageDest});
			this.groupBox2.Location = new System.Drawing.Point(240, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(224, 272);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Destination";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(61, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Image data";
			// 
			// textDest
			// 
			this.textDest.Location = new System.Drawing.Point(8, 240);
			this.textDest.Name = "textDest";
			this.textDest.Size = new System.Drawing.Size(208, 20);
			this.textDest.TabIndex = 0;
			this.textDest.Text = "";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(8, 224);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(51, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "Text data";
			// 
			// imageDest
			// 
			this.imageDest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.imageDest.Location = new System.Drawing.Point(8, 32);
			this.imageDest.Name = "imageDest";
			this.imageDest.Size = new System.Drawing.Size(208, 184);
			this.imageDest.TabIndex = 0;
			this.imageDest.TabStop = false;
			// 
			// copyImage
			// 
			this.copyImage.Location = new System.Drawing.Point(16, 288);
			this.copyImage.Name = "copyImage";
			this.copyImage.Size = new System.Drawing.Size(96, 23);
			this.copyImage.TabIndex = 1;
			this.copyImage.Text = "Copy Image";
			this.copyImage.Click += new System.EventHandler(this.copyImage_Click);
			// 
			// copyText
			// 
			this.copyText.Location = new System.Drawing.Point(128, 288);
			this.copyText.Name = "copyText";
			this.copyText.Size = new System.Drawing.Size(96, 23);
			this.copyText.TabIndex = 2;
			this.copyText.Text = "Copy Text";
			this.copyText.Click += new System.EventHandler(this.copyText_Click);
			// 
			// copyCustom
			// 
			this.copyCustom.Location = new System.Drawing.Point(16, 320);
			this.copyCustom.Name = "copyCustom";
			this.copyCustom.Size = new System.Drawing.Size(96, 23);
			this.copyCustom.TabIndex = 3;
			this.copyCustom.Text = "Copy Custom";
			this.copyCustom.Click += new System.EventHandler(this.copyCustom_Click);
			// 
			// pasteCustom
			// 
			this.pasteCustom.Location = new System.Drawing.Point(248, 320);
			this.pasteCustom.Name = "pasteCustom";
			this.pasteCustom.Size = new System.Drawing.Size(96, 23);
			this.pasteCustom.TabIndex = 8;
			this.pasteCustom.Text = "Paste Custom";
			this.pasteCustom.Click += new System.EventHandler(this.pasteCustom_Click);
			// 
			// pasteText
			// 
			this.pasteText.Location = new System.Drawing.Point(360, 288);
			this.pasteText.Name = "pasteText";
			this.pasteText.Size = new System.Drawing.Size(96, 23);
			this.pasteText.TabIndex = 7;
			this.pasteText.Text = "Paste Text";
			this.pasteText.Click += new System.EventHandler(this.pasteText_Click);
			// 
			// pasteImage
			// 
			this.pasteImage.Location = new System.Drawing.Point(248, 288);
			this.pasteImage.Name = "pasteImage";
			this.pasteImage.Size = new System.Drawing.Size(96, 23);
			this.pasteImage.TabIndex = 6;
			this.pasteImage.Text = "Paste Image";
			this.pasteImage.Click += new System.EventHandler(this.pasteImage_Click);
			// 
			// copyAll
			// 
			this.copyAll.Location = new System.Drawing.Point(128, 320);
			this.copyAll.Name = "copyAll";
			this.copyAll.Size = new System.Drawing.Size(96, 23);
			this.copyAll.TabIndex = 4;
			this.copyAll.Text = "Copy All";
			this.copyAll.Click += new System.EventHandler(this.copyAll_Click);
			// 
			// viewFormats
			// 
			this.viewFormats.Location = new System.Drawing.Point(360, 320);
			this.viewFormats.Name = "viewFormats";
			this.viewFormats.Size = new System.Drawing.Size(96, 23);
			this.viewFormats.TabIndex = 9;
			this.viewFormats.Text = "View Formats";
			this.viewFormats.Click += new System.EventHandler(this.viewFormats_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 347);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.viewFormats,
																		  this.copyAll,
																		  this.pasteCustom,
																		  this.pasteText,
																		  this.pasteImage,
																		  this.copyCustom,
																		  this.copyText,
																		  this.copyImage,
																		  this.groupBox2,
																		  this.groupBox1});
			this.Name = "MainForm";
			this.Text = "Using the Clipboard Part II";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void loadImage_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();

			ofd.Filter = "Image Files (*.jpg;*.gif;*.bmp;*.tga)|*.jpg;*.gif;*.bmp;*.tga";
			ofd.CheckFileExists = true;
			ofd.CheckPathExists = true;
			ofd.AddExtension = true;
			
			if( ofd.InitialDirectory == "" )
				ofd.InitialDirectory = Application.ExecutablePath;

			ofd.Multiselect = false;
			ofd.ShowHelp = false;
			ofd.ShowReadOnly = false;

			ofd.Title = "Open image...";

			if( ofd.ShowDialog() == DialogResult.OK )
			{
				imageSrc.Image = Bitmap.FromFile(ofd.FileName);
			}
		}

		private void CopyObject(string format, object data)
		{
			IDataObject od = new DataObject();
			od.SetData(format, true, data);

			Clipboard.SetDataObject(od, true);
		}

		private void copyImage_Click(object sender, System.EventArgs e)
		{
			CopyObject(DataFormats.Bitmap, imageSrc.Image);
		}
		
		private void copyText_Click(object sender, System.EventArgs e)
		{
			CopyObject(DataFormats.Text, textSrc.Text);
		}
		
		private void copyCustom_Click(object sender, System.EventArgs e)
		{
			CustomData cd = new CustomData(textSrc.Text, imageSrc.Image);
		
			CopyObject(CustomData.Format.Name, cd);
		}

		private void copyAll_Click(object sender, System.EventArgs e)
		{
			IDataObject ido = new DataObject();
			
			CustomData cd = new CustomData(textSrc.Text, imageSrc.Image);

			// Add our formats
			ido.SetData(CustomData.Format.Name, true, cd);
			ido.SetData(DataFormats.Text, true, cd.String);
			ido.SetData(DataFormats.Bitmap, true, cd.Image);

			// Finally add it to the clipboard
			Clipboard.SetDataObject(ido, true);
		}

		private void pasteImage_Click(object sender, System.EventArgs e)
		{
			IDataObject od = Clipboard.GetDataObject();

			if(od.GetDataPresent(DataFormats.Bitmap))
				imageDest.Image = (Bitmap) od.GetData(DataFormats.Bitmap, true);
		}

		private void pasteText_Click(object sender, System.EventArgs e)
		{
			IDataObject od = Clipboard.GetDataObject();

			if(od.GetDataPresent(DataFormats.Text))
				textDest.Text = (string) od.GetData(DataFormats.Text, true);
		}

		private void pasteCustom_Click(object sender, System.EventArgs e)
		{
			IDataObject od = Clipboard.GetDataObject();

			if(od.GetDataPresent(CustomData.Format.Name))
			{
				CustomData cd = od.GetData(CustomData.Format.Name) as CustomData;

				imageDest.Image = cd.Image;
				textDest.Text = cd.String;
			}
		}

		private void viewFormats_Click(object sender, System.EventArgs e)
		{
			IDataObject ido = Clipboard.GetDataObject();

			string [] formats = ido.GetFormats(true);

			string format = "";

			foreach(string f in formats)
				format += f + Environment.NewLine;

			MessageBox.Show(this, format, "Formats Added, and converted");
		}
	}
}
