using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ClipboardTest2
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private Bitmap bmp;
		private System.Windows.Forms.CheckBox checkBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			bmp = new Bitmap(300, 300);
			pictureBox1.Image = bmp;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}

				bmp.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(192, 168);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox2.Location = new System.Drawing.Point(208, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(192, 168);
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 192);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.Text = "Draw";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(96, 192);
			this.button2.Name = "button2";
			this.button2.TabIndex = 3;
			this.button2.Text = "Copy";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(216, 192);
			this.button3.Name = "button3";
			this.button3.TabIndex = 4;
			this.button3.Text = "Paste";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// checkBox1
			// 
			this.checkBox1.Checked = true;
			this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox1.Location = new System.Drawing.Point(8, 224);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.TabIndex = 5;
			this.checkBox1.Text = "Persist data";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(408, 251);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.checkBox1,
																		  this.button3,
																		  this.button2,
																		  this.button1,
																		  this.pictureBox2,
																		  this.pictureBox1});
			this.Name = "Form1";
			this.Text = "Clipboard Persist test";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			using(Graphics g = Graphics.FromImage(bmp))
			{
				Random r = new Random();

				for(int i = 0; i < 10000; i++)
				{
					int x = r.Next(300);
					int y = r.Next(300);

					int w = r.Next(150);
					int h = r.Next(150);
				
					using(Brush brush = new SolidBrush(Color.FromArgb(r.Next(255), r.Next(255), r.Next(255))))
					{
						g.FillRectangle(brush, x, y, w, h);
					}
				}
			}

			pictureBox1.Image = bmp;
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			IDataObject ido = new DataObject();

			ido.SetData(DataFormats.Bitmap, true, bmp);

			Clipboard.SetDataObject(ido, checkBox1.Checked);
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			Bitmap bitmap = (Bitmap) Clipboard.GetDataObject().GetData(DataFormats.Bitmap);

			if( pictureBox2.Image != null )
				pictureBox2.Image.Dispose();

			pictureBox2.Image = bitmap;
		}
	}
}
